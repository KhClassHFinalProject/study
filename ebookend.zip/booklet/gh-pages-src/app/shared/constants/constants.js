/* global toastr:false */
(function() {
	'use strict';

	angular
		.module('shared.constants')
		.constant('toastr', toastr);
})();
